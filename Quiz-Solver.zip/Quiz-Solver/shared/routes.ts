import { z } from 'zod';
import { insertQuizSchema, quizzes } from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  quizzes: {
    create: {
      method: 'POST' as const,
      path: '/api/quizzes',
      input: insertQuizSchema,
      responses: {
        201: z.custom<typeof quizzes.$inferSelect>(),
        400: errorSchemas.validation,
        500: errorSchemas.internal,
      },
    },
    list: {
        method: 'GET' as const,
        path: '/api/quizzes',
        responses: {
            200: z.array(z.custom<typeof quizzes.$inferSelect>())
        }
    },
    get: {
      method: 'GET' as const,
      path: '/api/quizzes/:id',
      responses: {
        200: z.custom<typeof quizzes.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
};

// ============================================
// REQUIRED: buildUrl helper
// ============================================
export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

// ============================================
// TYPE HELPERS
// ============================================
export type QuizInput = z.infer<typeof api.quizzes.create.input>;
export type QuizResponse = z.infer<typeof api.quizzes.create.responses[201]>;
export type QuizzesListResponse = z.infer<typeof api.quizzes.list.responses[200]>;
