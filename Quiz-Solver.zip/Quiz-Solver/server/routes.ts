import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";

const openai = new OpenAI({
    apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
    baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post(api.quizzes.create.path, async (req, res) => {
    try {
      const input = api.quizzes.create.input.parse(req.body);
      
      // Call OpenAI to generate answers
      const prompt = `
        You are a helpful study assistant. 
        Analyze the following quiz content and provide the correct answers with brief explanations.
        Return the response in a structured JSON format:
        {
            "title": "Quiz Title (inferred)",
            "questions": [
                {
                    "question": "Question text",
                    "answer": "Correct answer",
                    "explanation": "Brief explanation"
                }
            ]
        }
        
        Quiz Content:
        ${input.content}
      `;

      const completion = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
            { role: "system", content: "You are a helpful study assistant that solves quizzes." },
            { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
      });

      const answers = JSON.parse(completion.choices[0].message.content || "{}");

      const quiz = await storage.createQuiz({
        ...input,
        answers: answers
      });

      res.status(201).json(quiz);
    } catch (err) {
      console.error(err);
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Failed to generate quiz answers" });
    }
  });

  app.get(api.quizzes.list.path, async (req, res) => {
    const quizzes = await storage.getQuizzes();
    res.json(quizzes);
  });

  app.get(api.quizzes.get.path, async (req, res) => {
    const quiz = await storage.getQuiz(Number(req.params.id));
    if (!quiz) {
      return res.status(404).json({ message: 'Quiz not found' });
    }
    res.json(quiz);
  });

  return httpServer;
}
