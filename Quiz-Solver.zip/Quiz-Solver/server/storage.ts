import { db } from "./db";
import {
  quizzes,
  type Quiz,
  type InsertQuiz,
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  createQuiz(quiz: InsertQuiz & { answers: any }): Promise<Quiz>;
  getQuizzes(): Promise<Quiz[]>;
  getQuiz(id: number): Promise<Quiz | undefined>;
}

export class DatabaseStorage implements IStorage {
  async createQuiz(insertQuiz: InsertQuiz & { answers: any }): Promise<Quiz> {
    const [quiz] = await db
      .insert(quizzes)
      .values(insertQuiz)
      .returning();
    return quiz;
  }

  async getQuizzes(): Promise<Quiz[]> {
    return await db.select().from(quizzes).orderBy(desc(quizzes.createdAt));
  }

  async getQuiz(id: number): Promise<Quiz | undefined> {
    const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, id));
    return quiz;
  }
}

export const storage = new DatabaseStorage();
