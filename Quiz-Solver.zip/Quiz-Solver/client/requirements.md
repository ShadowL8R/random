## Packages
framer-motion | Smooth animations for page transitions and result reveals
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes safely
date-fns | Formatting dates for the history view

## Notes
The app uses a simple text-based input for quizzes.
AI processing happens on the backend; frontend handles the "loading" state.
The `answers` field in the database is JSONB. I will assume a structure or fallback to displaying raw text if unstructured.
