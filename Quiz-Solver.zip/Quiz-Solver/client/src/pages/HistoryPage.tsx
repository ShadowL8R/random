import { useQuizzes } from "@/hooks/use-quizzes";
import { Link } from "wouter";
import { format } from "date-fns";
import { Loader2, ArrowRight, FileText, CalendarClock, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";

export default function HistoryPage() {
  const { data: quizzes, isLoading, error } = useQuizzes();

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 text-primary animate-spin mb-4" />
        <p className="text-muted-foreground">Loading history...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-20">
        <p className="text-destructive font-medium">Failed to load quiz history.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <div className="mb-10">
        <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-4">
          History
        </h1>
        <p className="text-muted-foreground text-lg">
          View your past analyzed quizzes and study sessions.
        </p>
      </div>

      {!quizzes || quizzes.length === 0 ? (
        <div className="bg-muted/30 rounded-2xl border-2 border-dashed border-border p-12 text-center">
          <div className="w-16 h-16 bg-background rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
            <FileText className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-semibold text-foreground mb-2">No quizzes yet</h3>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            You haven't analyzed any quizzes yet. Start a new session to get AI-powered answers.
          </p>
          <Link 
            href="/"
            className="inline-flex items-center px-6 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20"
          >
            Start New Quiz
            <ArrowRight className="w-4 h-4 ml-2" />
          </Link>
        </div>
      ) : (
        <div className="grid gap-4">
          {quizzes.map((quiz, index) => {
             // Create a preview snippet from content or fallback
             const preview = quiz.content 
                ? (quiz.content.length > 100 ? quiz.content.substring(0, 100) + "..." : quiz.content)
                : "Image Upload Analysis";

             return (
              <motion.div
                key={quiz.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Link href={`/quiz/${quiz.id}`} className="block group">
                  <div className="bg-card hover:bg-accent/5 rounded-xl p-6 border border-border hover:border-accent/30 transition-all duration-200 shadow-sm hover:shadow-md flex items-center justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mb-2">
                        <span className="flex items-center bg-muted/50 px-2 py-1 rounded-md">
                           <CalendarClock className="w-3 h-3 mr-1" />
                           {quiz.createdAt && format(new Date(quiz.createdAt), "MMM d, yyyy • h:mm a")}
                        </span>
                        <span className="font-mono text-[10px] uppercase tracking-wider opacity-60">ID: {quiz.id}</span>
                      </div>
                      <h3 className="text-lg font-medium text-foreground truncate pr-4 group-hover:text-primary transition-colors font-display">
                        {preview}
                      </h3>
                    </div>
                    
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-background border border-border flex items-center justify-center group-hover:border-primary/30 group-hover:text-primary transition-all">
                      <ChevronRight className="w-5 h-5" />
                    </div>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
