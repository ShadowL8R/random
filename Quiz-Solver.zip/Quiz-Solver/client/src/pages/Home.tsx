import { QuizInputForm } from "@/components/QuizInputForm";
import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-[calc(100vh-4rem)] bg-background flex flex-col items-center justify-center p-4 sm:p-6 lg:p-8">
      
      {/* Hero Section */}
      <div className="text-center max-w-2xl mx-auto mb-12">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center px-3 py-1 rounded-full bg-primary/5 text-primary text-xs font-semibold mb-6 border border-primary/10"
        >
          <Sparkles className="w-3 h-3 mr-2" />
          AI-Powered Learning Assistant
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold text-foreground mb-6 tracking-tight"
        >
          Master your quizzes with <span className="text-primary">confidence.</span>
        </motion.h1>

        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-lg sm:text-xl text-muted-foreground leading-relaxed"
        >
          Paste your quiz content or upload a screenshot. Our advanced AI will analyze questions, identify correct answers, and provide detailed explanations to help you learn.
        </motion.p>
      </div>

      {/* Input Form Section */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="w-full"
      >
        <QuizInputForm />
      </motion.div>
    </div>
  );
}
