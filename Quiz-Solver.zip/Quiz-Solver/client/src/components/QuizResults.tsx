import { motion } from "framer-motion";
import { CheckCircle2, HelpCircle, BookOpen } from "lucide-react";
import { cn } from "@/lib/utils";
import type { QuizResponse } from "@shared/routes";

// Define a type for the parsed JSON structure of answers
// This assumes the AI backend returns a structure similar to this
interface ParsedQuestion {
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
}

interface QuizResultsProps {
  quiz: QuizResponse;
}

export function QuizResults({ quiz }: QuizResultsProps) {
  // Safety check and parsing for the JSON content
  let parsedContent: ParsedQuestion[] | string = [];
  
  try {
    if (typeof quiz.answers === 'string') {
        parsedContent = JSON.parse(quiz.answers);
    } else {
        parsedContent = quiz.answers as unknown as ParsedQuestion[];
    }
  } catch (e) {
    console.error("Failed to parse answers", e);
    parsedContent = "Error parsing results format.";
  }

  // Fallback for unstructured text response
  if (typeof parsedContent === 'string' || !Array.isArray(parsedContent)) {
    return (
      <div className="bg-card rounded-2xl shadow-sm border border-border p-8 prose prose-slate max-w-none">
         <h3 className="text-xl font-bold mb-4">Analysis Result</h3>
         <pre className="whitespace-pre-wrap font-sans text-foreground/80 leading-relaxed">
           {JSON.stringify(quiz.answers, null, 2).replace(/^"|"$/g, '').replace(/\\n/g, '\n')}
         </pre>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {parsedContent.map((item, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: index * 0.1 }}
          className="bg-card rounded-2xl shadow-sm border border-border overflow-hidden hover:shadow-md transition-shadow duration-300"
        >
          {/* Question Header */}
          <div className="p-6 bg-muted/30 border-b border-border/50 flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold font-mono text-sm">
              {index + 1}
            </div>
            <h3 className="text-lg font-medium text-foreground leading-relaxed">
              {item.question}
            </h3>
          </div>

          <div className="p-6 space-y-6">
            {/* Options (if available) */}
            {item.options && item.options.length > 0 && (
              <div className="grid gap-3 sm:grid-cols-2">
                {item.options.map((option, optIndex) => {
                  // Very basic matching logic - in a real app, IDs would be safer
                  const isCorrect = option.includes(item.correctAnswer) || item.correctAnswer.includes(option);
                  return (
                    <div
                      key={optIndex}
                      className={cn(
                        "p-3 rounded-lg border text-sm transition-colors",
                        isCorrect
                          ? "bg-green-50 border-green-200 text-green-900 dark:bg-green-900/20 dark:border-green-800 dark:text-green-100 font-medium"
                          : "bg-background border-input text-muted-foreground opacity-70"
                      )}
                    >
                      <div className="flex items-start gap-2">
                         <div className={cn(
                             "w-4 h-4 rounded-full border flex-shrink-0 mt-0.5",
                             isCorrect ? "border-green-500 bg-green-500" : "border-muted-foreground"
                         )} />
                         {option}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Answer & Explanation */}
            <div className="bg-amber-50 dark:bg-amber-900/10 rounded-xl p-5 border border-amber-100 dark:border-amber-900/30">
              <div className="flex items-start gap-3 mb-3">
                <CheckCircle2 className="w-5 h-5 text-amber-600 dark:text-amber-500 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-amber-900 dark:text-amber-100 mb-1">
                    Correct Answer
                  </h4>
                  <p className="text-amber-800 dark:text-amber-200/80 font-medium">
                    {item.correctAnswer}
                  </p>
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t border-amber-200/50 dark:border-amber-800/30 flex items-start gap-3">
                <BookOpen className="w-5 h-5 text-amber-600/70 dark:text-amber-500/70 mt-0.5" />
                <div>
                  <h4 className="text-sm font-semibold text-amber-900/80 dark:text-amber-100/80 uppercase tracking-wider text-xs mb-1">
                    Explanation
                  </h4>
                  <p className="text-sm text-amber-800/90 dark:text-amber-200/70 leading-relaxed">
                    {item.explanation}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
