import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertQuizSchema } from "@shared/schema";
import { useCreateQuiz } from "@/hooks/use-quizzes";
import { useLocation } from "wouter";
import { Loader2, Wand2, FileText, Image as ImageIcon } from "lucide-react";
import { z } from "zod";

// Create a client-side schema that extends the base schema or uses it directly
// We're making content required here for the form
const formSchema = z.object({
    content: z.string().min(10, "Please enter at least 10 characters of quiz content"),
    imageUrl: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export function QuizInputForm() {
  const [activeTab, setActiveTab] = useState<"text" | "image">("text");
  const [, setLocation] = useLocation();
  const createQuiz = useCreateQuiz();

  const { register, handleSubmit, formState: { errors } } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      content: "",
      imageUrl: "",
    },
  });

  const onSubmit = (data: FormValues) => {
    createQuiz.mutate(data, {
      onSuccess: (quiz) => {
        setLocation(`/quiz/${quiz.id}`);
      },
    });
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className="bg-card rounded-2xl shadow-xl shadow-black/5 border border-border overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-border bg-muted/30">
          <h2 className="text-2xl font-display font-bold text-foreground">Analyze New Quiz</h2>
          <p className="text-muted-foreground mt-1">Paste your quiz content below to get AI-powered answers and explanations.</p>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-border">
          <button
            onClick={() => setActiveTab("text")}
            className={`flex-1 py-4 text-sm font-medium flex items-center justify-center transition-colors ${
              activeTab === "text"
                ? "bg-background text-primary border-b-2 border-primary"
                : "bg-muted/50 text-muted-foreground hover:text-foreground"
            }`}
          >
            <FileText className="w-4 h-4 mr-2" />
            Text Input
          </button>
          <button
            onClick={() => setActiveTab("image")}
            className={`flex-1 py-4 text-sm font-medium flex items-center justify-center transition-colors ${
              activeTab === "image"
                ? "bg-background text-primary border-b-2 border-primary"
                : "bg-muted/50 text-muted-foreground hover:text-foreground"
            }`}
          >
            <ImageIcon className="w-4 h-4 mr-2" />
            Image URL (Beta)
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 md:p-8 space-y-6">
          {activeTab === "text" && (
            <div className="space-y-3">
              <label className="block text-sm font-medium text-foreground">
                Quiz Content
              </label>
              <textarea
                {...register("content")}
                className="w-full h-64 p-4 rounded-xl border border-input bg-background focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all resize-none font-mono text-sm leading-relaxed"
                placeholder="Paste your quiz questions here..."
              />
              {errors.content && (
                <p className="text-sm text-destructive">{errors.content.message}</p>
              )}
            </div>
          )}

          {activeTab === "image" && (
            <div className="space-y-3">
              <label className="block text-sm font-medium text-foreground">
                Image URL
              </label>
              <input
                {...register("imageUrl")}
                type="url"
                className="w-full p-4 rounded-xl border border-input bg-background focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                placeholder="https://example.com/quiz-screenshot.jpg"
              />
              <p className="text-xs text-muted-foreground">
                Note: Image analysis is currently in beta. Text input provides better accuracy.
              </p>
            </div>
          )}

          <div className="pt-4 flex items-center justify-end">
            <button
              type="submit"
              disabled={createQuiz.isPending}
              className="
                group relative px-8 py-3 rounded-xl font-semibold overflow-hidden
                bg-primary text-primary-foreground shadow-lg shadow-primary/25
                hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5
                active:translate-y-0 active:shadow-md
                disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none
                transition-all duration-200 ease-out
              "
            >
              <span className="relative z-10 flex items-center">
                {createQuiz.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4 mr-2 group-hover:rotate-12 transition-transform" />
                    Solve Quiz
                  </>
                )}
              </span>
              {/* Subtle shine effect on hover */}
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
